-- phpMyAdmin SQL Dump
-- version 3.3.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 17, 2011 at 12:43 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.2-1ubuntu4.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `my-heart`
--

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE IF NOT EXISTS `message` (
  `message_id` int(11) NOT NULL AUTO_INCREMENT,
  `message_text` varchar(255) NOT NULL,
  `message_parsed` tinyint(1) NOT NULL,
  `message_visible` tinyint(1) NOT NULL,
  `message_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `message_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`message_id`),
  KEY `message_text` (`message_text`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`message_id`, `message_text`, `message_parsed`, `message_visible`, `message_created`, `message_updated`) VALUES
(1, 'Я тестую відправку повідомлень через JS API', 0, 0, '2011-12-11 01:20:46', '2011-12-11 03:20:46'),
(2, 'Я тестую відправку повідомлень через JS API2', 0, 0, '2011-12-11 01:21:20', '2011-12-11 03:21:20'),
(3, 'Я тестую відправку повідомлень через JS API3', 0, 0, '2011-12-11 01:22:31', '2011-12-11 03:22:31'),
(4, 'Я тестую відправку повідомлень через JS API4', 0, 0, '2011-12-11 01:23:36', '2011-12-11 03:23:36'),
(5, 'Отправить', 0, 0, '2011-12-12 18:44:47', '2011-12-12 20:44:47'),
(6, 'Влад', 0, 0, '2011-12-12 18:46:32', '2011-12-12 20:53:04'),
(7, 'Пишу повідомлення', 0, 0, '2011-12-12 18:50:35', '2011-12-12 20:50:35'),
(8, 'Альона', 0, 0, '2011-12-12 18:53:42', '2011-12-12 20:53:42'),
(9, 'Альона2', 0, 0, '2011-12-12 18:58:14', '2011-12-12 20:58:14'),
(10, 'Альона3', 0, 0, '2011-12-12 18:59:21', '2011-12-12 20:59:21');

-- --------------------------------------------------------

--
-- Table structure for table `message_sent`
--

CREATE TABLE IF NOT EXISTS `message_sent` (
  `message_sent_id` int(11) NOT NULL AUTO_INCREMENT,
  `message_id` int(11) NOT NULL,
  `message_sent_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `message_sent_update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `message_received_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `message_sent_from` int(11) NOT NULL,
  `message_sent_to` int(11) NOT NULL,
  `message_sent_status` int(11) NOT NULL,
  PRIMARY KEY (`message_sent_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `message_sent`
--

INSERT INTO `message_sent` (`message_sent_id`, `message_id`, `message_sent_date`, `message_sent_update_date`, `message_received_date`, `message_sent_from`, `message_sent_to`, `message_sent_status`) VALUES
(26, 6, '2011-12-12 18:51:39', '2011-12-12 21:08:59', '0000-00-00 00:00:00', 6134519, 25453454, 1),
(32, 8, '2011-12-12 19:00:26', '2011-12-12 21:00:28', '0000-00-00 00:00:00', 5701489, 10241847, 4),
(31, 10, '2011-12-12 18:59:21', '2011-12-12 20:59:25', '0000-00-00 00:00:00', 5701489, 10241847, 1),
(30, 9, '2011-12-12 18:59:02', '2011-12-12 20:59:05', '0000-00-00 00:00:00', 5701489, 10241847, 4),
(29, 9, '2011-12-12 18:58:14', '2011-12-12 20:58:48', '0000-00-00 00:00:00', 5701489, 10241847, 4),
(33, 1, '2011-12-12 19:04:39', '2011-12-12 21:04:52', '0000-00-00 00:00:00', 5701489, 10241847, 4),
(34, 1, '2011-12-12 19:05:15', '2011-12-12 21:05:31', '0000-00-00 00:00:00', 5701489, 10241847, 4),
(35, 1, '2011-12-12 19:06:05', '2011-12-12 21:06:11', '0000-00-00 00:00:00', 5701489, 10241847, 4),
(36, 1, '2011-12-12 19:07:24', '2011-12-12 21:08:07', '0000-00-00 00:00:00', 5701489, 10241847, 4),
(37, 1, '2011-12-12 19:08:50', '2011-12-12 21:08:59', '0000-00-00 00:00:00', 5701489, 10241847, 4);
